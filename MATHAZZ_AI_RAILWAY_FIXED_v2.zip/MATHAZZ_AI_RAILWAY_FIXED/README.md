# MATHAZZ AI — Railway Worker

This project runs as a Railway Worker (Telegram long polling).

## Deploy
1. Upload all files in this folder to the root of your GitHub repository.
2. In Railway, use a Worker service connected to that repository.
3. Set the start command to `python main.py` (or let `railway.toml` provide it).
4. Add environment variables in Railway → Variables:
   - `BOT_TOKEN` (required)
   - `GEMINI_API_KEY` (optional, for Gemini AI)
   - `GROQ_API_KEY` (optional, backup AI provider)
   - `TWELVE_DATA_API_KEY` (optional, if using Twelve Data)
   - `DATA_PROVIDER=auto` (optional)
5. Deploy with one replica for Telegram polling.

The bot uses Python standard-library modules only; `requirements.txt` is included so Railpack detects the Python project.
